# Local Project Performance & API Auditor Pro — Advanced Version 3.0

> **A production-quality, Windows-compatible, local-first web application for auditing website loading performance, Core Web Vitals, API requests, React components, Next.js applications, Python-backed services, CSS, dependencies, and source code bottlenecks.**

---

## ⚡ What makes Version 3.0 different?

Most performance tools merely report *what* is slow (e.g. "LCP is 3.8s"). Auditor Pro v3.0 identifies:
1. **Which exact file, component, function, endpoint, or selector** is causing the bottleneck.
2. The **exact project-relative file path and line numbers** (e.g. `src/components/ProductList.jsx` lines `42–68`).
3. The **existing source code block** sliced directly from the file.
4. The **corrected replacement code** ready to substitute.
5. The **exact replacement instructions, required imports, and side effects**.
6. **Why the fix helps**, expected latency/render reductions, and trade-offs.
7. Safe **patch preview, unified diffs, atomic backups (`.auditor-backups/`), and instant rollback**.

---

## 📋 System Requirements

- **Operating System:** Windows 10, Windows 11, macOS, or Linux.
- **Node.js:** Node.js 18.0.0 or newer (Node.js 20+ LTS recommended).
- **Python (Optional):** Python 3.8+ for deep Python AST analysis (a pure JS parser fallback is included if Python is not installed).
- **Browser Automation:** Playwright Chromium (automatically installed by `start.bat`).

---

## 🚀 Quick Start (Windows)

### 1. One-Click Startup
Double-click `start.bat` in the project root:
```bat
start.bat
```
`start.bat` will automatically:
1. Check that Node.js and npm are installed.
2. Install dependencies via `npm install` if missing.
3. Download Playwright Chromium if needed (`npx playwright install chromium`).
4. Start the server on `http://127.0.0.1:4890`.
5. Automatically open the dashboard in your default browser.
6. Keep the terminal window open with error diagnostics if anything fails.

### 2. Manual Startup (Cross-Platform)
On Windows PowerShell, macOS, or Linux:
```bash
# Install dependencies
npm install

# Install Playwright browser
npx playwright install chromium

# Launch the server
npm start
```
Open [http://127.0.0.1:4890](http://127.0.0.1:4890) in your browser.

### 3. Graceful Shutdown (Windows)
Double-click `stop.bat` to terminate any running Auditor server processes on port 4890.

---

## 🔍 How to Run Audits

### Scenario A: Auditing a Website URL
1. Enter your website target (e.g. `http://localhost:3000` or `https://myapp.local`) in the **Website Target URL** input.
2. Select **Desktop** or **Mobile Viewport (iPhone 14)**.
3. Choose **Cold Cache** or **Warm Cache Mode**.
4. Select number of test runs (1 run for quick check, 3 or 5 for statistical median).
5. Click **Run Comprehensive Audit**.

### Scenario B: Auditing a Local Source Repository
1. Enter your project's local directory path in **Local Project Directory Path**, for example:
   - `D:\projects\my-react-app`
   - `D:\projects\my-nextjs-app`
   - `C:\workspace\python-fastapi-service`
2. Click **Run Comprehensive Audit**.
3. Auditor Pro traverses the source tree (skipping `node_modules`, `.git`, `.venv`), runs AST and pattern rules across React, Next.js, Python, CSS, and `package.json`, and outputs itemized findings.

### Scenario C: Correlated Combined Audit (Most Powerful)
Provide **both** the Target URL **and** the Project Directory:
- Auditor Pro records runtime API calls (e.g. `GET /api/products`).
- Correlates each runtime request with the exact component and line in your source code that issued the fetch!
- Flags duplicates, waterfalls, and slow endpoints with clickable source references.

---

## 🛠 Supported Analysis Rules & Bottlenecks

### 1. React & Next.js
- **Missing Request Cancellation:** Identifies `fetch()` or `axios()` inside `useEffect` without `AbortController` and unmount cleanup. Proposes complete replacement block with `AbortError` handling.
- **Sequential Network Waterfalls:** Identifies multiple independent sequential `await fetch()` calls that could be parallelized with `Promise.all()`.
- **Unmemoized Render Calculations:** Detects `.filter().sort().map()` chains in component bodies re-evaluating on every render; wraps in `useMemo`.
- **Uncleaned Timers & Listeners:** Detects `setInterval` or `addEventListener` in effects without cleanup return functions (memory leaks).
- **Unstable Array Index Keys:** Detects `map((item, index) => <div key={index}>)` and substitutes stable unique identifiers.
- **Next.js Client Boundaries:** Flags unnecessary `'use client'` on components without hooks or browser APIs, converting them to zero-bundle Server Components (RSC).
- **Unoptimized `<img>` Tags:** Replaces raw HTML `<img>` with Next.js `next/image` for WebP/AVIF compression and responsive sizing.
- **Heavy Static Components:** Flags large visualization/editor libraries (e.g. Chart.js, Monaco) imported statically instead of with `next/dynamic`.

### 2. Python & Backend
- **Async Event Loop Blocking:** Detects synchronous blocking `requests.get()` inside `async def` endpoints that freeze the single-threaded asyncio loop. Proposes non-blocking `httpx.AsyncClient` or `aiohttp`.
- **N+1 Database Queries:** Flags queries (`session.query()`, `Model.objects.filter()`) executed inside loops. Proposes batched `WHERE IN` or joined loading.
- **Missing Request Timeouts:** Flags `requests.get()` without `timeout=...`, preventing permanent thread starvation on network drops.

### 3. CSS & Styling
- **Layout-Triggering Animations:** Detects `@keyframes` animating `top`, `left`, `width`, `height`, or `margin` that trigger reflow/repaint on every frame; replaces with GPU-accelerated `transform` (3D translate/scale).
- **Render-Blocking `@import`:** Flags `@import url(...)` at the top of stylesheets that introduce network waterfalls.
- **Excessive Selector Specificity:** Flags selectors with &ge; 5 combinators.

### 4. Dependencies & Bundles
- **Legacy & Bloated Packages:** Identifies monolithic `moment` (saves ~65KB by migrating to `date-fns` or native `Intl`) and default `lodash` imports.
- **Redundant Libraries:** Warns when multiple HTTP libraries (e.g. `axios` and `node-fetch`) are both present.
- **Oversized Build Chunks:** Examines `.next/`, `dist/`, or `build/` outputs and flags JavaScript chunks exceeding 250KB.

---

## 🔒 Safe Patch Workflow & Rollback

Auditor Pro never silently modifies project files. It enforces a strict, atomic safety pipeline:
1. **Read-Only Inspection:** Generates a unified diff preview (`--- a/... +++ b/...`) without touching the filesystem.
2. **Staleness Verification:** Computes the SHA-256 hash of the target file. If the file was edited after the audit was run, the patch is marked stale and blocked until a re-scan.
3. **Explicit User Approval:** Requires user confirmation before any disk write.
4. **Atomic Backup:** Automatically snapshots the original file to `.auditor-backups/<backup-id>/` along with a cryptographic `manifest.json`.
5. **Post-Write Verification:** Re-reads the file to verify integrity.
6. **One-Click Rollback:** Allows instant restoration of previous versions from the Backups panel.
7. **Downloadable `.patch`:** Provides standard unified diff files for review with `git apply`.

---

## 📊 Performance Scoring & Deductions

Auditor Pro features a 100% transparent, explainable scoring engine:
- **Overall Score (0–100):** Weighted combination of Page Performance (25%), Network/API (20%), React/JS (20%), Python/Backend (15%), CSS (10%), and Dependencies (10%).
- **Explainability Panel:** Every point deduction is documented with the exact metric or code finding that caused it (e.g. *"TTFB is 1120ms (>800ms threshold): -6 pts"*).
- **Not a Black Box:** Heuristic scores are clearly labeled and separated from official Lighthouse laboratory measurements.

---

## 📈 Before-and-After Comparison

1. Execute an audit on your baseline project.
2. Apply an approved patch or optimize the code.
3. Run a second audit.
4. Open the **Run Comparison** tab, select Run A and Run B, and view the comparison scorecard showing absolute deltas and percentage improvements for Core Web Vitals, request counts, payload sizes, and remaining findings.

---

## 🤖 Optional AI Analysis (Opt-In)

- **Completely Optional & Local-First:** Core static AST parsing and browser auditing run 100% locally with zero internet dependency or API keys.
- **Configurable Endpoint:** Connects to any OpenAI-compatible API (e.g. local Ollama at `http://localhost:11434/v1`, LocalAI, or OpenAI).
- **Automated Credential Redaction:** Before any code snippet is previewed or sent, API keys, JWT tokens, AWS keys, passwords, and cookies are masked.
- **Prompt Preview:** Displays the exact payload that would be transmitted for user sign-off.

---

## 🛡 Security & Privacy Guarantees

- **127.0.0.1 Binding Only:** The server listens strictly on the loopback interface, preventing remote network access.
- **Strict Path Validation:** Validates that all scanned and patched files reside strictly within the user-specified project root. Directory traversal (`../`) is blocked.
- **System Path Protection:** Access to root directories (`/`, `C:\`, `C:\Windows`, `/etc`, etc.) is strictly forbidden.
- **Ignored Directories:** Skips `.git`, `node_modules`, `.venv`, and temporary caches to prevent sensitive exposure.
- **Zero Telemetry:** No tracking, analytics, or remote telemetry is included.

---

## 📂 Project Architecture

```
local-project-performance-api-auditor-pro-v3/
├── package.json               # Package definition & scripts
├── start.bat                  # One-click Windows setup and launch
├── stop.bat                   # Windows process termination helper
├── server.js                  # Local-first REST API & static server (127.0.0.1)
├── README.md                  # Comprehensive user and architecture guide
├── .gitignore                 # Version control exclusions
├── src/
│   ├── audit/
│   │   ├── audit-runner.js    # Master orchestrator & multi-run manager
│   │   ├── scoring.js         # Transparent deduction-based scoring
│   │   └── run-comparator.js  # Before/after delta comparison
│   ├── browser/
│   │   ├── playwright-auditor.js # Playwright Chromium CWV & request tracker
│   │   └── synthetic-timing.js   # High-precision HTTP timing fallback
│   ├── network/
│   │   ├── request-inventory.js  # Request categorization & size breakdown
│   │   ├── api-classifier.js     # Heuristic and content-type API detector
│   │   ├── waterfall-detector.js # Waterfall and duplicate request finder
│   │   └── call-source-correlator.js # Endpoint-to-source-code matcher
│   ├── source-analysis/
│   │   ├── project-scanner.js    # Directory traversal & scanner orchestrator
│   │   ├── ast-engine.js         # Scope, delimiter, and symbol parser
│   │   ├── line-mapper.js        # 1-indexed line numbers and content hashes
│   │   └── finding-generator.js  # Standardized finding schema
│   ├── react-analysis/
│   │   ├── react-rules.js        # React hooks, rendering, waterfalls, imports
│   │   └── nextjs-rules.js       # 'use client', image tags, dynamic imports
│   ├── python-analysis/
│   │   ├── python-ast-scanner.py # Python standard library AST scanner
│   │   └── python-rules.js       # Node wrapper & pure JS fallback
│   ├── css-analysis/
│   │   └── css-rules.js          # Layout animations, @import, specificity
│   ├── dependency-analysis/
│   │   └── dependency-rules.js   # Heavy and redundant package detection
│   ├── bundle-analysis/
│   │   └── bundle-inspector.js   # Chunk analysis for .next, dist, build
│   ├── patches/
│   │   ├── patch-generator.js    # Unified diff and patch file builder
│   │   ├── diff-engine.js        # Visual side-by-side diff renderer
│   │   ├── safe-backup.js        # Atomic snapshots in .auditor-backups
│   │   └── patch-applier.js      # Stale check, safe patch application, rollback
│   ├── reports/
│   │   ├── json-reporter.js      # Complete JSON data export
│   │   ├── csv-reporter.js       # Network & findings CSV exports
│   │   ├── html-reporter.js      # Standalone self-contained HTML report
│   │   └── pdf-reporter.js       # Printable PDF-formatted report
│   └── security/
│       ├── path-validator.js     # Path traversal and system path guard
│       ├── url-sanitizer.js      # Protocol validation & token redaction
│       ├── redaction.js          # Secret masking engine
│       └── ai-service.js         # Opt-in OpenAI-compatible integration
├── public/
│   ├── index.html             # Responsive dashboard user interface
│   ├── styles.css             # Dark-mode styling, gauges, diffs, tables
│   └── app.js                 # Frontend state and API controller
├── tests/
│   ├── test-url-sanitizer.js  # Protocol and query redaction tests
│   ├── test-path-validator.js # Traversal and extension tests
│   ├── test-source-analysis.js# React, Python, CSS, Dependency AST tests
│   ├── test-patch-engine.js   # Diff, backup, patch, and rollback tests
│   ├── test-api-classifier.js # Classification and duplicate tests
│   ├── test-reports.js        # Export generation tests
│   └── run-all-tests.js       # Master test suite runner (npm test)
├── examples/
│   ├── sample-react-app/      # Real React components with bottlenecks
│   ├── sample-python-api/     # Real Python endpoints with async blocking
│   └── sample-css-project/    # Real CSS with layout animations
└── docs/
    ├── ARCHITECTURE.md        # Technical architecture deep dive
    ├── AUDIT_RULES.md         # Full catalog of detection rules
    ├── PATCHING_AND_SAFETY.md # Guide to safe patching, hashing, and rollback
    └── TROUBLESHOOTING.md     # Diagnostic guide and FAQ
```

---

## 🧪 Running Automated Tests

Run the full automated test suite anytime:
```bash
npm test
```
Or directly with Node:
```bash
node tests/run-all-tests.js
```
The test suite validates:
- URL protocol validation and credential stripping.
- Directory traversal prevention and system path safety.
- AST pattern scanning for React, Next.js, Python, CSS, and dependencies.
- Line number accuracy and slice mapping.
- Unified diff generation, backup snapshot creation, and atomic rollback.
- Export formatting for JSON, CSV, HTML, and PDF.

---

## 📄 License

MIT License. Designed for local developer environments.
