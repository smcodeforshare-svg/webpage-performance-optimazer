import React, { useState, useEffect } from 'react';

export function DashboardStats() {
  const [userStats, setUserStats] = useState(null);
  const [revenueStats, setRevenueStats] = useState(null);

  // Bottleneck: Sequential waterfall fetches in effect instead of Promise.all
  useEffect(() => {
    async function loadData() {
      const res1 = await fetch('/api/user-stats');
      const res2 = await fetch('/api/revenue-stats');
      const data1 = await res1.json();
      const data2 = await res2.json();
      setUserStats(data1);
      setRevenueStats(data2);
    }
    loadData();
  }, []);

  return (
    <div>
      <h3>Dashboard Stats</h3>
    </div>
  );
}
