import React, { useState, useEffect } from 'react';
import _ from 'lodash';
import moment from 'moment';

export function ProductList({ searchTerm }) {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('all');

  // Bottleneck 1: Fetch without AbortController or unmount cleanup
  useEffect(() => {
    fetch('/api/products')
      .then(response => response.json())
      .then(data => setProducts(data));
  }, [searchTerm]);

  // Bottleneck 2: Expensive chained array transformation in render body without useMemo
  const sortedProducts = products.filter(p => p.active).sort((a, b) => b.price - a.price);

  return (
    <div className="product-list">
      <h2>Products (Updated: {moment().format('LL')})</h2>
      <ul>
        {/* Bottleneck 3: Unstable array index used as key */}
        {sortedProducts.map((item, index) => (
          <li key={index} className="product-item">
            <span>{item.name}</span>
            <span>${item.price}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
