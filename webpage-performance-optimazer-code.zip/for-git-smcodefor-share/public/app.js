/**
 * Local Project Performance & API Auditor Pro v3.0
 * Frontend Application Controller
 */

// Application State
const state = {
  currentRun: null,
  activePatchFinding: null,
  activeFilter: 'all',
  requestFilter: 'all',
  runsList: []
};

// DOM References
const auditForm = document.getElementById('auditForm');
const targetUrlInput = document.getElementById('targetUrl');
const projectPathInput = document.getElementById('projectPath');
const isMobileCheckbox = document.getElementById('isMobile');
const warmCacheCheckbox = document.getElementById('warmCache');
const screenshotCheckbox = document.getElementById('screenshot');
const repeatRunsSelect = document.getElementById('repeatRuns');
const runAuditBtn = document.getElementById('runAuditBtn');
const progressBanner = document.getElementById('progressBanner');
const progressText = document.getElementById('progressText');

// Tabs
const tabButtons = document.querySelectorAll('.tab-btn');
const tabPanes = document.querySelectorAll('.tab-pane');

// Scorecard elements
const ringOverall = document.getElementById('ringOverall');
const scorePage = document.getElementById('scorePage');
const scoreNetwork = document.getElementById('scoreNetwork');
const scoreReact = document.getElementById('scoreReact');
const scorePython = document.getElementById('scorePython');
const scoreCss = document.getElementById('scoreCss');
const scoreDeps = document.getElementById('scoreDeps');

// Vitals
const vitalTtfb = document.getElementById('vitalTtfb');
const vitalFcp = document.getElementById('vitalFcp');
const vitalLcp = document.getElementById('vitalLcp');
const vitalCls = document.getElementById('vitalCls');
const navTimingBar = document.getElementById('navTimingBar');
const navTimingLegend = document.getElementById('navTimingLegend');

// Stats
const statTotalReqs = document.getElementById('statTotalReqs');
const statTotalSize = document.getElementById('statTotalSize');
const statApiReqs = document.getElementById('statApiReqs');
const statFailedReqs = document.getElementById('statFailedReqs');
const statSlowReqs = document.getElementById('statSlowReqs');
const statThirdParty = document.getElementById('statThirdParty');
const deductionsList = document.getElementById('deductionsList');

// Findings
const countFindings = document.getElementById('countFindings');
const findingsContainer = document.getElementById('findingsContainer');
const findingsSearch = document.getElementById('findingsSearch');
const severityFilter = document.getElementById('severityFilter');
const confidenceFilter = document.getElementById('confidenceFilter');
const categoryFilter = document.getElementById('categoryFilter');

// Requests
const countRequests = document.getElementById('countRequests');
const requestsTableBody = document.getElementById('requestsTableBody');
const requestsSearch = document.getElementById('requestsSearch');
const reqFilterChips = document.querySelectorAll('.chip');

// Patching
const patchDiffViewer = document.getElementById('patchDiffViewer');
const patchFileMeta = document.getElementById('patchFileMeta');
const applyPatchBtn = document.getElementById('applyPatchBtn');
const downloadPatchBtn = document.getElementById('downloadPatchBtn');
const backupsList = document.getElementById('backupsList');

// Specialized Tabs
const reactFindingsList = document.getElementById('reactFindingsList');
const pythonFindingsList = document.getElementById('pythonFindingsList');
const cssFindingsList = document.getElementById('cssFindingsList');
const depFindingsList = document.getElementById('depFindingsList');
const bundleChunksSection = document.getElementById('bundleChunksSection');

// Comparison
const compareRunA = document.getElementById('compareRunA');
const compareRunB = document.getElementById('compareRunB');
const compareBtn = document.getElementById('compareBtn');
const comparisonResults = document.getElementById('comparisonResults');

// Modal
const modalBackdrop = document.getElementById('modalBackdrop');
const modalTitle = document.getElementById('modalTitle');
const modalBody = document.getElementById('modalBody');
const modalFooter = document.getElementById('modalFooter');
const modalCloseBtn = document.getElementById('modalCloseBtn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  setupTabs();
  setupFilters();
  setupExports();
  loadSavedRuns();
});

// Tab Switcher
function setupTabs() {
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const pane = document.getElementById(target);
      if (pane) pane.classList.add('active');
    });
  });
}

function switchTab(tabId) {
  const btn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
  if (btn) btn.click();
}

// Form Submission
auditForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const targetUrl = targetUrlInput.value.trim();
  const projectPath = projectPathInput.value.trim();

  if (!targetUrl && !projectPath) {
    alert('Please provide either a Target URL or a Local Project Directory path (or both).');
    return;
  }

  setLoading(true, 'Running performance tests, capturing requests, and parsing source code...');

  try {
    const res = await fetch('/api/audit/full', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetUrl: targetUrl || undefined,
        projectPath: projectPath || undefined,
        isMobile: isMobileCheckbox.checked,
        warmCache: warmCacheCheckbox.checked,
        screenshot: screenshotCheckbox.checked,
        repeatRuns: repeatRunsSelect.value
      })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Audit failed');

    state.currentRun = data;
    renderAudit(data);
    loadSavedRuns();
  } catch (err) {
    alert(`Audit Error: ${err.message}`);
  } finally {
    setLoading(false);
  }
});

function setLoading(isLoading, text = '') {
  if (isLoading) {
    progressBanner.classList.remove('hidden');
    progressText.textContent = text;
    runAuditBtn.disabled = true;
  } else {
    progressBanner.classList.add('hidden');
    runAuditBtn.disabled = false;
  }
}

// Render Master Audit Data
function renderAudit(data) {
  const scores = data.scores || {};
  const web = data.webAudit || {};
  const metrics = web.metrics || {};
  const net = web.requestSummary || {};
  const source = data.sourceAudit || {};
  const findings = source.findings || [];
  const requests = web.requests || [];

  // 1. Scorecards
  ringOverall.textContent = scores.overall ?? '--';
  scorePage.textContent = scores.page ?? '--';
  scoreNetwork.textContent = scores.network ?? '--';
  scoreReact.textContent = scores.reactJs ?? '--';
  scorePython.textContent = scores.python ?? '--';
  scoreCss.textContent = scores.css ?? '--';
  scoreDeps.textContent = scores.dependencies ?? '--';

  colorScore(ringOverall, scores.overall);
  colorScore(scorePage, scores.page);
  colorScore(scoreNetwork, scores.network);
  colorScore(scoreReact, scores.reactJs);
  colorScore(scorePython, scores.python);
  colorScore(scoreCss, scores.css);
  colorScore(scoreDeps, scores.dependencies);

  // 2. Vitals
  vitalTtfb.textContent = metrics.ttfbMs ? `${metrics.ttfbMs} ms` : '--';
  vitalFcp.textContent = metrics.fcpMs ? `${metrics.fcpMs} ms` : '--';
  vitalLcp.textContent = metrics.lcpMs ? `${metrics.lcpMs} ms` : '--';
  vitalCls.textContent = metrics.cls !== undefined && metrics.cls !== null ? metrics.cls : '--';

  // 3. Navigation Timing Bar
  renderNavigationTimeline(metrics);

  // 4. Request Summary Stats
  statTotalReqs.textContent = net.totalRequests ?? 0;
  statTotalSize.textContent = `${net.totalTransferredKb ?? 0} KB`;
  statApiReqs.textContent = net.apiRequestsCount ?? 0;
  statFailedReqs.textContent = net.failedRequestsCount ?? 0;
  statSlowReqs.textContent = net.slowRequestsCount ?? 0;
  statThirdParty.textContent = net.thirdPartyRequestsCount ?? 0;

  // 5. Deductions
  renderDeductions(scores.deductions || {});

  // 6. Counts
  countFindings.textContent = findings.length;
  countRequests.textContent = requests.length;

  // 7. Findings & Lists
  renderFindings(findings);
  renderSpecializedFindings(findings, source.bundleSummary);
  renderRequests(requests);

  // 8. Auto-populate project path in settings / backups if available
  if (data.projectPath) {
    loadBackups(data.projectPath);
  }
}

function colorScore(elem, score) {
  if (score === undefined || score === null) return;
  elem.style.color = score >= 80 ? 'var(--success)' : score >= 60 ? 'var(--warning)' : 'var(--danger)';
}

function renderNavigationTimeline(metrics) {
  navTimingBar.innerHTML = '';
  navTimingLegend.innerHTML = '';

  const total = metrics.navigationDurationMs || 1000;
  const segments = [
    { label: 'DNS', duration: metrics.dnsDurationMs || 0, color: '#38bdf8' },
    { label: 'TCP/TLS', duration: (metrics.connectDurationMs || 0) + (metrics.tlsDurationMs || 0), color: '#818cf8' },
    { label: 'TTFB (Wait)', duration: metrics.ttfbMs || 0, color: '#f59e0b' },
    { label: 'Download', duration: metrics.downloadDurationMs || 0, color: '#10b981' }
  ];

  segments.forEach(seg => {
    const widthPct = Math.max(1, Math.min(100, (seg.duration / total) * 100));
    const div = document.createElement('div');
    div.className = 'timing-segment';
    div.style.width = `${widthPct}%`;
    div.style.backgroundColor = seg.color;
    div.title = `${seg.label}: ${seg.duration}ms`;
    navTimingBar.appendChild(div);

    const legend = document.createElement('div');
    legend.className = 'legend-item';
    legend.innerHTML = `<span class="legend-dot" style="background:${seg.color}"></span>${seg.label}: ${seg.duration}ms`;
    navTimingLegend.appendChild(legend);
  });
}

function renderDeductions(deductions) {
  deductionsList.innerHTML = '';
  let hasDeductions = false;

  for (const [category, items] of Object.entries(deductions)) {
    if (items && items.length > 0) {
      hasDeductions = true;
      const catDiv = document.createElement('div');
      catDiv.style.marginBottom = '10px';
      catDiv.innerHTML = `<strong>${category.toUpperCase()}:</strong>`;
      const ul = document.createElement('ul');
      ul.style.paddingLeft = '20px';
      ul.style.fontSize = '13px';
      ul.style.color = 'var(--text-muted)';
      items.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        ul.appendChild(li);
      });
      catDiv.appendChild(ul);
      deductionsList.appendChild(catDiv);
    }
  }

  if (!hasDeductions) {
    deductionsList.innerHTML = '<p class="empty-text" style="color:var(--success)">No score deductions! Outstanding performance and clean code patterns.</p>';
  }
}

// Findings Rendering
function renderFindings(findings) {
  findingsContainer.innerHTML = '';

  const filtered = filterFindings(findings);
  if (filtered.length === 0) {
    findingsContainer.innerHTML = '<p class="empty-text">No findings match the selected filters.</p>';
    return;
  }

  filtered.forEach(f => {
    const card = document.createElement('div');
    card.className = `finding-card ${f.severity}`;
    card.innerHTML = `
      <div class="finding-top">
        <div>
          <span class="badge ${f.severity}">${f.severity.toUpperCase()}</span>
          <span class="badge ${f.confidence}">${f.confidence.replace('_', ' ')}</span>
          <span class="badge" style="background:#1e293b">${f.category}</span>
          <span class="finding-title">${escapeHtml(f.title)}</span>
        </div>
        <button class="btn btn-secondary btn-sm preview-patch-btn" data-id="${f.id}">View Proposed Fix</button>
      </div>

      <div class="finding-file">
        <strong>File:</strong> <code>${escapeHtml(f.filePath)}</code> &bull; Lines: <strong>${f.startLine}–${f.endLine}</strong> &bull; Symbol: <code>${escapeHtml(f.symbol)}</code>
      </div>

      <div class="finding-evidence">
        <strong>Detected:</strong> ${escapeHtml(f.evidence)}
      </div>

      <div class="code-diff-container">
        <div class="code-panel">
          <div class="panel-header">Existing Code Block (Lines ${f.startLine}–${f.endLine})</div>
          <pre><code>${escapeHtml(f.existingCode)}</code></pre>
        </div>
        <div class="code-panel">
          <div class="panel-header" style="color:var(--success)">Corrected Replacement Code</div>
          <pre><code>${escapeHtml(f.replacementCode)}</code></pre>
        </div>
      </div>

      <div class="finding-footer">
        <div style="font-size:12px; color:var(--text-muted)">
          <strong>Expected Benefit:</strong> ${escapeHtml(f.whyFixHelps?.expectedBenefit || 'Performance optimization')}
        </div>
        <div>
          <button class="btn btn-primary btn-sm apply-now-btn" data-id="${f.id}">Apply Safe Patch</button>
        </div>
      </div>
    `;

    // Hook buttons
    card.querySelector('.preview-patch-btn').addEventListener('click', () => openPatchPreview(f));
    card.querySelector('.apply-now-btn').addEventListener('click', () => triggerApplyPatch(f));

    findingsContainer.appendChild(card);
  });
}

function filterFindings(findings) {
  const query = findingsSearch.value.toLowerCase().trim();
  const sev = severityFilter.value;
  const conf = confidenceFilter.value;
  const cat = categoryFilter.value;

  return findings.filter(f => {
    if (sev !== 'all' && f.severity !== sev) return false;
    if (conf !== 'all' && f.confidence !== conf) return false;
    if (cat !== 'all' && !f.category.includes(cat)) return false;
    if (query) {
      const hay = `${f.title} ${f.filePath} ${f.symbol} ${f.evidence}`.toLowerCase();
      if (!hay.includes(query)) return false;
    }
    return true;
  });
}

function setupFilters() {
  findingsSearch.addEventListener('input', () => renderFindings(state.currentRun?.sourceAudit?.findings || []));
  severityFilter.addEventListener('change', () => renderFindings(state.currentRun?.sourceAudit?.findings || []));
  confidenceFilter.addEventListener('change', () => renderFindings(state.currentRun?.sourceAudit?.findings || []));
  categoryFilter.addEventListener('change', () => renderFindings(state.currentRun?.sourceAudit?.findings || []));

  requestsSearch.addEventListener('input', () => renderRequests(state.currentRun?.webAudit?.requests || []));
  reqFilterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      reqFilterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.requestFilter = chip.dataset.reqFilter;
      renderRequests(state.currentRun?.webAudit?.requests || []);
    });
  });
}

function renderSpecializedFindings(findings, bundleSummary) {
  // React
  const reactList = findings.filter(f => f.category.startsWith('react') || f.category.startsWith('nextjs'));
  reactFindingsList.innerHTML = reactList.length > 0 ? '' : '<p class="empty-text">No React or Next.js findings.</p>';
  reactList.forEach(f => reactFindingsList.appendChild(createSummaryCard(f)));

  // Python
  const pythonList = findings.filter(f => f.category.startsWith('python'));
  pythonFindingsList.innerHTML = pythonList.length > 0 ? '' : '<p class="empty-text">No Python findings.</p>';
  pythonList.forEach(f => pythonFindingsList.appendChild(createSummaryCard(f)));

  // CSS
  const cssList = findings.filter(f => f.category.startsWith('css'));
  cssFindingsList.innerHTML = cssList.length > 0 ? '' : '<p class="empty-text">No CSS findings.</p>';
  cssList.forEach(f => cssFindingsList.appendChild(createSummaryCard(f)));

  // Dependencies
  const depList = findings.filter(f => f.category.startsWith('dependency'));
  depFindingsList.innerHTML = depList.length > 0 ? '' : '<p class="empty-text">No dependency findings.</p>';
  depList.forEach(f => depFindingsList.appendChild(createSummaryCard(f)));

  // Bundle Chunks
  bundleChunksSection.innerHTML = '';
  if (bundleSummary && bundleSummary.hasBuildArtifacts) {
    bundleChunksSection.innerHTML = `
      <div style="margin-bottom:20px; padding:16px; background:var(--bg-main); border:1px solid var(--border); border-radius:8px">
        <h4>Build Chunks Inspected (${bundleSummary.buildType} - ${bundleSummary.buildDir})</h4>
        <p style="font-size:13px; color:var(--text-muted); margin-bottom:10px">Total bundle size: <strong>${bundleSummary.totalBundleSizeKb} KB</strong></p>
        <div style="max-height:200px; overflow-y:auto">
          <table class="data-table">
            <thead><tr><th>Chunk Name</th><th>Size (KB)</th></tr></thead>
            <tbody>
              ${bundleSummary.chunks.slice(0, 20).map(c => `<tr><td><code>${c.name}</code></td><td>${c.sizeKb} KB</td></tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }
}

function createSummaryCard(f) {
  const div = document.createElement('div');
  div.className = `finding-card ${f.severity}`;
  div.innerHTML = `
    <div class="finding-top">
      <div>
        <span class="badge ${f.severity}">${f.severity.toUpperCase()}</span>
        <span class="finding-title">${escapeHtml(f.title)}</span>
      </div>
      <button class="btn btn-secondary btn-sm" onclick="openPatchPreviewById('${f.id}')">View Fix</button>
    </div>
    <div class="finding-file"><code>${escapeHtml(f.filePath)}:${f.startLine}</code></div>
    <div style="font-size:13px; color:var(--text-muted)">${escapeHtml(f.evidence)}</div>
  `;
  return div;
}

window.openPatchPreviewById = function(id) {
  const f = state.currentRun?.sourceAudit?.findings?.find(item => item.id === id);
  if (f) openPatchPreview(f);
};

// Network Requests Rendering
function renderRequests(requests) {
  requestsTableBody.innerHTML = '';

  const filtered = filterRequests(requests);
  if (filtered.length === 0) {
    requestsTableBody.innerHTML = '<tr><td colspan="7" class="empty-cell">No requests match the selected filters.</td></tr>';
    return;
  }

  filtered.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${r.method}</strong></td>
      <td><span class="badge ${r.status >= 400 || r.isFailed ? 'critical' : 'verified'}">${r.status || 'ERR'}</span></td>
      <td class="url-cell" title="${escapeHtml(r.url)}">${escapeHtml(r.url)}</td>
      <td>${r.durationMs} ms</td>
      <td>${Math.round(r.transferSizeBytes / 1024)} KB</td>
      <td>${r.isApi ? '<span class="badge" style="background:#064e3b; color:#6ee7b7">API</span>' : escapeHtml(r.resourceType)}</td>
      <td>${r.correlatedSource ? `<a href="javascript:void(0)" class="correlated-link" style="color:var(--primary)">${escapeHtml(r.correlatedSource.filePath)}:${r.correlatedSource.line}</a>` : '<span style="color:var(--text-dim)">-</span>'}</td>
    `;
    requestsTableBody.appendChild(tr);
  });
}

function filterRequests(requests) {
  const query = requestsSearch.value.toLowerCase().trim();
  const type = state.requestFilter;

  return requests.filter(r => {
    if (type === 'api' && !r.isApi) return false;
    if (type === 'slow' && !r.isSlow) return false;
    if (type === 'failed' && !r.isFailed) return false;
    if (type === 'third-party' && !r.isThirdParty) return false;

    if (query && !r.url.toLowerCase().includes(query)) return false;
    return true;
  });
}

// Patch Preview & Application
async function openPatchPreview(finding) {
  state.activePatchFinding = finding;
  switchTab('tabPatching');

  patchFileMeta.innerHTML = `Preparing unified diff for <code>${escapeHtml(finding.filePath)}</code> (Lines ${finding.startLine}–${finding.endLine})...`;
  patchDiffViewer.textContent = 'Generating unified diff...';
  applyPatchBtn.disabled = true;
  downloadPatchBtn.disabled = true;

  const projectPath = state.currentRun?.projectPath || projectPathInput.value.trim();

  try {
    const res = await fetch('/api/patch/preview', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectPath, finding })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    patchFileMeta.innerHTML = `
      <strong>File:</strong> <code>${escapeHtml(finding.filePath)}</code> &bull;
      Replace lines <strong>${finding.startLine}–${finding.endLine}</strong> &bull;
      Status: ${data.isStale ? '<span class="badge critical">STALE ON DISK</span>' : '<span class="badge verified">READY TO APPLY</span>'}
    `;

    patchDiffViewer.textContent = data.unifiedDiff;
    applyPatchBtn.disabled = data.isStale;
    downloadPatchBtn.disabled = false;

    downloadPatchBtn.onclick = () => {
      downloadFile(`${finding.symbol || 'patch'}.patch`, data.unifiedDiff, 'text/x-diff');
    };
  } catch (err) {
    patchFileMeta.textContent = `Error: ${err.message}`;
    patchDiffViewer.textContent = err.message;
  }
}

applyPatchBtn.addEventListener('click', () => {
  if (state.activePatchFinding) {
    triggerApplyPatch(state.activePatchFinding);
  }
});

async function triggerApplyPatch(finding) {
  const projectPath = state.currentRun?.projectPath || projectPathInput.value.trim();
  if (!projectPath) {
    alert('Project path is required to apply patches.');
    return;
  }

  const confirmed = confirm(`Are you sure you want to apply the proposed patch to '${finding.filePath}'? A backup will automatically be saved in .auditor-backups/ first.`);
  if (!confirmed) return;

  try {
    const res = await fetch('/api/patch/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectPath, finding })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    alert(`Patch applied successfully! Backup preserved at '${data.backupId}'.`);
    loadBackups(projectPath);
  } catch (err) {
    alert(`Failed to apply patch: ${err.message}`);
  }
}

async function loadBackups(projectPath) {
  // In v3.0, list backups from local directory
  backupsList.innerHTML = '<p class="empty-text">Backups available in <code>' + escapeHtml(projectPath) + '/.auditor-backups/</code></p>';
}

// Comparison
async function loadSavedRuns() {
  try {
    const res = await fetch('/api/runs');
    const data = await res.json();
    state.runsList = data.runs || [];

    compareRunA.innerHTML = '';
    compareRunB.innerHTML = '';

    state.runsList.forEach(run => {
      const optA = document.createElement('option');
      optA.value = run.id;
      optA.textContent = `${run.id} (${run.timestamp.slice(0, 16)}) - Score: ${run.overallScore}`;
      compareRunA.appendChild(optA);

      const optB = document.createElement('option');
      optB.value = run.id;
      optB.textContent = `${run.id} (${run.timestamp.slice(0, 16)}) - Score: ${run.overallScore}`;
      compareRunB.appendChild(optB);
    });

    if (state.runsList.length >= 2) {
      compareRunB.selectedIndex = 1;
    }
  } catch {}
}

compareBtn.addEventListener('click', async () => {
  const runAId = compareRunA.value;
  const runBId = compareRunB.value;

  if (!runAId || !runBId) {
    alert('Please select two runs to compare.');
    return;
  }

  try {
    const res = await fetch('/api/compare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ runAId, runBId })
    });

    const diff = await res.json();
    if (!res.ok) throw new Error(diff.error);

    renderComparison(diff);
  } catch (err) {
    alert(`Comparison failed: ${err.message}`);
  }
});

function renderComparison(diff) {
  const row = (name, item, suffix = '') => {
    const color = item.status === 'better' ? 'var(--success)' : item.status === 'worse' ? 'var(--danger)' : 'var(--text-muted)';
    return `
      <tr>
        <td><strong>${name}</strong></td>
        <td>${item.valA}${suffix}</td>
        <td>${item.valB}${suffix}</td>
        <td style="color:${color}; font-weight:bold">${item.delta > 0 ? '+' : ''}${item.delta}${suffix} (${item.pct}%)</td>
      </tr>
    `;
  };

  comparisonResults.innerHTML = `
    <div class="grid-card full-width" style="margin-top:20px">
      <h3>Run Delta Comparison: ${escapeHtml(diff.runAId)} vs ${escapeHtml(diff.runBId)}</h3>
      <table class="data-table">
        <thead><tr><th>Metric</th><th>Baseline (A)</th><th>Current (B)</th><th>Delta</th></tr></thead>
        <tbody>
          ${row('Overall Score', diff.scores.overall, ' pts')}
          ${row('Page Perf Score', diff.scores.page, ' pts')}
          ${row('Network Score', diff.scores.network, ' pts')}
          ${row('Time to First Byte (TTFB)', diff.webMetrics.ttfbMs, ' ms')}
          ${row('First Contentful Paint (FCP)', diff.webMetrics.fcpMs, ' ms')}
          ${row('Largest Contentful Paint (LCP)', diff.webMetrics.lcpMs, ' ms')}
          ${row('Cumulative Layout Shift (CLS)', diff.webMetrics.cls)}
          ${row('Total HTTP Requests', diff.network.totalRequests)}
          ${row('API Requests Count', diff.network.apiRequestsCount)}
          ${row('Payload Transferred', diff.network.totalTransferredKb, ' KB')}
          ${row('Total Code Bottlenecks', diff.findings.totalFindings)}
        </tbody>
      </table>
    </div>
  `;
}

// Exports
function setupExports() {
  const getRunId = () => state.currentRun?.id;

  document.getElementById('btnExportHtml').addEventListener('click', () => {
    const id = getRunId();
    if (!id) return alert('Run an audit first.');
    window.open(`/api/export/${id}/html`, '_blank');
  });

  document.getElementById('btnExportJson').addEventListener('click', () => {
    const id = getRunId();
    if (!id) return alert('Run an audit first.');
    window.open(`/api/export/${id}/json`, '_blank');
  });

  document.getElementById('btnExportCsvReqs').addEventListener('click', () => {
    const id = getRunId();
    if (!id) return alert('Run an audit first.');
    window.open(`/api/export/${id}/csv-requests`, '_blank');
  });

  document.getElementById('btnExportCsvFindings').addEventListener('click', () => {
    const id = getRunId();
    if (!id) return alert('Run an audit first.');
    window.open(`/api/export/${id}/csv-findings`, '_blank');
  });

  document.getElementById('btnExportPdf').addEventListener('click', () => {
    const id = getRunId();
    if (!id) return alert('Run an audit first.');
    window.open(`/api/export/${id}/pdf`, '_blank');
  });
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
