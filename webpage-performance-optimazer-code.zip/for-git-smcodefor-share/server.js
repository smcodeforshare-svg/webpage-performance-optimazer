/**
 * Local Project Performance & API Auditor Pro — Advanced Version 3.0
 * Local-First Web Server
 * Strictly binds to 127.0.0.1 for local privacy and security.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const AuditRunner = require('./src/audit/audit-runner');
const RunComparator = require('./src/audit/run-comparator');
const PatchApplier = require('./src/patches/patch-applier');
const JsonReporter = require('./src/reports/json-reporter');
const CsvReporter = require('./src/reports/csv-reporter');
const HtmlReporter = require('./src/reports/html-reporter');
const PdfReporter = require('./src/reports/pdf-reporter');
const AIService = require('./src/security/ai-service');

const PORT = Number(process.env.PORT) || 4890;
const HOST = '127.0.0.1'; // Mandatory: never expose on 0.0.0.0 or remote interface

const runner = new AuditRunner();
const aiService = new AIService();

// MIME types for serving public files
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

/**
 * Request handler supporting both built-in HTTP and API routes
 */
async function handleRequest(req, res) {
  const parsedUrl = new URL(req.url, `http://${HOST}:${PORT}`);
  const pathname = parsedUrl.pathname;
  const method = req.method.toUpperCase();

  // Helper for JSON responses
  const sendJson = (statusCode, data) => {
    res.writeHead(statusCode, {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': `http://127.0.0.1:${PORT}`,
      'Cache-Control': 'no-store'
    });
    res.end(JSON.stringify(data));
  };

  // Helper for text/html responses
  const sendText = (statusCode, text, contentType = 'text/plain; charset=utf-8') => {
    res.writeHead(statusCode, {
      'Content-Type': contentType,
      'Cache-Control': 'no-store'
    });
    res.end(text);
  };

  // Parse JSON body
  const readBody = () => new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) { // 5MB limit
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error(`Invalid JSON body: ${err.message}`));
      }
    });
    req.on('error', reject);
  });

  try {
    // 1. API: System Status
    if (pathname === '/api/status' && method === 'GET') {
      let hasPlaywright = false;
      try {
        require('playwright');
        hasPlaywright = true;
      } catch {}

      return sendJson(200, {
        status: 'online',
        version: '3.0.0',
        host: HOST,
        port: PORT,
        capabilities: {
          playwright: hasPlaywright,
          aiConfigured: aiService.getStatus().hasKeyConfigured,
          aiEnabled: aiService.getStatus().enabled
        }
      });
    }

    // 2. API: List saved runs
    if (pathname === '/api/runs' && method === 'GET') {
      const runs = runner.listRuns();
      return sendJson(200, { runs });
    }

    // 3. API: Get single run
    const runMatch = pathname.match(/^\/api\/runs\/([a-zA-Z0-9_-]+)$/);
    if (runMatch && method === 'GET') {
      const runId = runMatch[1];
      const data = runner.getRun(runId);
      if (!data) return sendJson(404, { error: 'Audit run not found' });
      return sendJson(200, data);
    }

    // 4. API: Run Website Performance Audit
    if (pathname === '/api/audit/website' && method === 'POST') {
      const body = await readBody();
      const targetUrl = body.targetUrl;
      if (!targetUrl) return sendJson(400, { error: 'Target URL is required' });

      const result = await runner.runFullAudit({
        targetUrl,
        isMobile: body.isMobile,
        warmCache: body.warmCache,
        repeatRuns: body.repeatRuns
      });
      return sendJson(200, result);
    }

    // 5. API: Run Local Source Code Project Scan
    if (pathname === '/api/audit/source' && method === 'POST') {
      const body = await readBody();
      const projectPath = body.projectPath;
      if (!projectPath) return sendJson(400, { error: 'Project directory path is required' });

      const result = await runner.runFullAudit({ projectPath });
      return sendJson(200, result);
    }

    // 6. API: Run Full Combined Audit
    if (pathname === '/api/audit/full' && method === 'POST') {
      const body = await readBody();
      const result = await runner.runFullAudit({
        targetUrl: body.targetUrl,
        projectPath: body.projectPath,
        isMobile: body.isMobile,
        warmCache: body.warmCache,
        repeatRuns: body.repeatRuns
      });
      return sendJson(200, result);
    }

    // 7. API: Compare Runs
    if (pathname === '/api/compare' && method === 'POST') {
      const body = await readBody();
      const runA = runner.getRun(body.runAId);
      const runB = runner.getRun(body.runBId);

      if (!runA || !runB) {
        return sendJson(404, { error: 'One or both runs were not found.' });
      }

      const comparison = RunComparator.compare(runA, runB);
      return sendJson(200, comparison);
    }

    // 8. API: Patch Preview
    if (pathname === '/api/patch/preview' && method === 'POST') {
      const body = await readBody();
      const preview = PatchApplier.preview(body.projectPath, body.finding);
      return sendJson(200, preview);
    }

    // 9. API: Patch Apply
    if (pathname === '/api/patch/apply' && method === 'POST') {
      const body = await readBody();
      const result = PatchApplier.apply(body.projectPath, body.finding);
      return sendJson(result.success ? 200 : 400, result);
    }

    // 10. API: Patch Rollback
    if (pathname === '/api/patch/rollback' && method === 'POST') {
      const body = await readBody();
      const result = PatchApplier.rollback(body.projectPath, body.backupId);
      return sendJson(result.success ? 200 : 400, result);
    }

    // 11. API: Exports
    const exportMatch = pathname.match(/^\/api\/export\/([a-zA-Z0-9_-]+)\/([a-zA-Z0-9_-]+)$/);
    if (exportMatch && method === 'GET') {
      const runId = exportMatch[1];
      const format = exportMatch[2].toLowerCase();
      const run = runner.getRun(runId);

      if (!run) return sendJson(404, { error: 'Audit run not found' });

      if (format === 'json') {
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': `attachment; filename="${runId}.json"`
        });
        return res.end(JsonReporter.generate(run));
      }

      if (format === 'csv-requests') {
        res.writeHead(200, {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="${runId}-requests.csv"`
        });
        return res.end(CsvReporter.generateRequestsCsv(run.webAudit?.requests || []));
      }

      if (format === 'csv-findings') {
        res.writeHead(200, {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="${runId}-findings.csv"`
        });
        return res.end(CsvReporter.generateFindingsCsv(run.sourceAudit?.findings || []));
      }

      if (format === 'html') {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Disposition': `attachment; filename="${runId}-report.html"`
        });
        return res.end(HtmlReporter.generate(run));
      }

      if (format === 'pdf') {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Disposition': `inline; filename="${runId}-printable.html"`
        });
        return res.end(PdfReporter.generatePrintableHtml(run));
      }

      return sendJson(400, { error: `Unsupported export format: ${format}` });
    }

    // 12. API: Optional AI Assistance
    if (pathname === '/api/ai/status' && method === 'GET') {
      return sendJson(200, aiService.getStatus());
    }

    if (pathname === '/api/ai/preview' && method === 'POST') {
      const body = await readBody();
      const preview = aiService.previewPromptPayload(body.finding, body.snippet);
      return sendJson(200, preview);
    }

    if (pathname === '/api/ai/analyze' && method === 'POST') {
      const body = await readBody();
      const result = await aiService.analyzeFinding(body.finding, body.snippet);
      return sendJson(result.success ? 200 : 400, result);
    }

    // 13. Static File Serving from /public
    let relativeFilePath = pathname === '/' ? 'index.html' : pathname.replace(/^\//, '');
    const safeFilePath = path.normalize(relativeFilePath).replace(/^(\.\.[\/\\])+/, '');
    const fullStaticPath = path.join(__dirname, 'public', safeFilePath);

    // Ensure requested file stays inside public folder
    if (!fullStaticPath.startsWith(path.join(__dirname, 'public'))) {
      return sendText(403, 'Forbidden');
    }

    if (fs.existsSync(fullStaticPath) && fs.statSync(fullStaticPath).isFile()) {
      const ext = path.extname(fullStaticPath).toLowerCase();
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      const fileStream = fs.createReadStream(fullStaticPath);
      res.writeHead(200, { 'Content-Type': mime });
      return fileStream.pipe(res);
    }

    return sendJson(404, { error: 'Not Found' });
  } catch (err) {
    console.error('Server error:', err);
    return sendJson(500, { error: err.message || 'Internal Server Error' });
  }
}

// Start Server
const server = http.createServer(handleRequest);

server.listen(PORT, HOST, () => {
  console.log('================================================================');
  console.log(' Local Project Performance & API Auditor Pro — Advanced v3.0');
  console.log(` Running locally on: http://${HOST}:${PORT}`);
  console.log(' Bound strictly to 127.0.0.1 for maximum privacy and safety.');
  console.log('================================================================');
});

// Graceful termination
process.on('SIGINT', () => {
  console.log('\nShutting down Auditor Pro server cleanly...');
  server.close(() => process.exit(0));
});

process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});

module.exports = { server, handleRequest };
