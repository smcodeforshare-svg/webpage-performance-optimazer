/**
 * API Call-to-Source Correlator
 * Matches runtime HTTP/API requests with exact project source code files, components, and line numbers.
 */

const fs = require('fs');
const path = require('path');
const { URL } = require('url');

class CallSourceCorrelator {
  /**
   * Correlates runtime requests with local project source files
   * @param {Array<Object>} requests 
   * @param {string} projectRoot 
   * @param {Array<string>} sourceFiles List of relative file paths in project
   */
  static correlate(requests, projectRoot, sourceFiles = []) {
    const fileCache = new Map();

    const getFileLines = (relPath) => {
      if (fileCache.has(relPath)) return fileCache.get(relPath);
      try {
        const full = path.join(projectRoot, relPath);
        const text = fs.readFileSync(full, 'utf8');
        const lines = text.split(/\r?\n/);
        fileCache.set(relPath, { text, lines });
        return { text, lines };
      } catch {
        return null;
      }
    };

    const correlatedRequests = [];

    for (const req of requests) {
      const copy = { ...req, correlatedSource: null };

      if (!req.isApi || !projectRoot) {
        correlatedRequests.push(copy);
        continue;
      }

      let pathname = '';
      try {
        pathname = new URL(req.url).pathname;
      } catch {
        pathname = req.url;
      }

      // Skip root or trivial path
      if (!pathname || pathname === '/' || pathname.length < 3) {
        correlatedRequests.push(copy);
        continue;
      }

      let bestMatch = null;

      // Scan project source files for references to this path
      for (const relPath of sourceFiles) {
        // Look primarily in components, api, pages, services, hooks
        const cached = getFileLines(relPath);
        if (!cached) continue;

        if (cached.text.includes(pathname)) {
          // Find exact line
          for (let i = 0; i < cached.lines.length; i++) {
            const line = cached.lines[i];
            if (line.includes(pathname)) {
              bestMatch = {
                filePath: relPath,
                line: i + 1,
                snippet: line.trim(),
                confidence: 'strongly_supported',
                evidence: `Source file directly references endpoint path '${pathname}'.`
              };
              break;
            }
          }
        }

        if (bestMatch) break;
      }

      copy.correlatedSource = bestMatch;
      correlatedRequests.push(copy);
    }

    return correlatedRequests;
  }
}

module.exports = CallSourceCorrelator;
