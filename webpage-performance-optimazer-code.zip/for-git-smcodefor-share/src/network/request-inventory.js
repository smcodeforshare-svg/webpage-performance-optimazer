/**
 * Request Inventory Collector
 * Tracks, categorizes, and aggregates all HTTP/HTTPS network traffic during page auditing.
 */

const { sanitizeUrl } = require('../security/url-sanitizer');
const { redactHeaders } = require('../security/redaction');
const ApiClassifier = require('./api-classifier');
const { URL } = require('url');

class RequestInventory {
  constructor(initialUrl = '') {
    this.initialUrl = initialUrl;
    let initialHost = '';
    try {
      initialHost = new URL(initialUrl).hostname.toLowerCase();
    } catch {}
    this.initialHost = initialHost;

    this.requests = [];
  }

  /**
   * Adds a completed request event to the inventory
   * @param {Object} rawReq 
   */
  addRequest(rawReq) {
    const cleanUrl = sanitizeUrl(rawReq.url || '');
    const cleanHeaders = redactHeaders(rawReq.headers || {});
    const cleanResponseHeaders = redactHeaders(rawReq.responseHeaders || {});

    const classification = ApiClassifier.classify({
      url: cleanUrl,
      resourceType: rawReq.resourceType,
      method: rawReq.method,
      responseHeaders: cleanResponseHeaders,
      headers: cleanHeaders
    });

    let host = '';
    try {
      host = new URL(cleanUrl).hostname.toLowerCase();
    } catch {}

    const isThirdParty = Boolean(this.initialHost && host && !host.endsWith(this.initialHost) && !this.initialHost.endsWith(host));

    const duration = Number(rawReq.duration || rawReq.timing?.duration || 0);
    const status = Number(rawReq.status || 0);
    const isFailed = status >= 400 || rawReq.failed === true || rawReq.errorText;
    const isSlow = duration > 500; // Flag requests taking longer than 500ms

    const record = {
      id: `req-${this.requests.length + 1}`,
      url: cleanUrl,
      method: (rawReq.method || 'GET').toUpperCase(),
      status,
      statusText: rawReq.statusText || '',
      resourceType: rawReq.resourceType || 'other',
      durationMs: Math.round(duration),
      transferSizeBytes: Number(rawReq.transferSize || rawReq.size || 0),
      decodedBodySizeBytes: Number(rawReq.decodedBodySize || 0),
      isApi: classification.isApi,
      apiClassificationReason: classification.reason,
      isThirdParty,
      isFailed,
      isSlow,
      errorText: rawReq.errorText || null,
      initiator: rawReq.initiator || 'unknown',
      timing: {
        dns: Math.round(rawReq.timing?.dns || 0),
        connect: Math.round(rawReq.timing?.connect || 0),
        ssl: Math.round(rawReq.timing?.ssl || 0),
        ttfb: Math.round(rawReq.timing?.ttfb || rawReq.timing?.wait || 0),
        download: Math.round(rawReq.timing?.download || rawReq.timing?.receive || 0)
      },
      headers: cleanHeaders,
      responseHeaders: cleanResponseHeaders,
      timestamp: rawReq.timestamp || Date.now()
    };

    this.requests.push(record);
    return record;
  }

  /**
   * Produces an aggregated summary breakdown
   */
  getSummary() {
    let totalTransferred = 0;
    const byType = {};
    let apiCount = 0;
    let failedCount = 0;
    let slowCount = 0;
    let thirdPartyCount = 0;
    let thirdPartyTransferred = 0;

    for (const req of this.requests) {
      totalTransferred += req.transferSizeBytes;

      const type = req.resourceType || 'other';
      if (!byType[type]) {
        byType[type] = { count: 0, sizeBytes: 0, sizeKb: 0 };
      }
      byType[type].count++;
      byType[type].sizeBytes += req.transferSizeBytes;
      byType[type].sizeKb = Math.round(byType[type].sizeBytes / 1024);

      if (req.isApi) apiCount++;
      if (req.isFailed) failedCount++;
      if (req.isSlow) slowCount++;
      if (req.isThirdParty) {
        thirdPartyCount++;
        thirdPartyTransferred += req.transferSizeBytes;
      }
    }

    return {
      totalRequests: this.requests.length,
      totalTransferredBytes: totalTransferred,
      totalTransferredKb: Math.round(totalTransferred / 1024),
      apiRequestsCount: apiCount,
      failedRequestsCount: failedCount,
      slowRequestsCount: slowCount,
      thirdPartyRequestsCount: thirdPartyCount,
      thirdPartyTransferredKb: Math.round(thirdPartyTransferred / 1024),
      byType
    };
  }

  getAll() {
    return this.requests;
  }
}

module.exports = RequestInventory;
