const assert = require('assert');
const ApiClassifier = require('../src/network/api-classifier');
const RequestInventory = require('../src/network/request-inventory');
const WaterfallDetector = require('../src/network/waterfall-detector');

function testApiClassifier() {
  console.log('Running test: API Classifier & Waterfall Detector...');

  // 1. API Classification
  const c1 = ApiClassifier.classify({
    url: 'https://example.com/api/products',
    resourceType: 'fetch',
    method: 'GET'
  });
  assert.strictEqual(c1.isApi, true);

  const c2 = ApiClassifier.classify({
    url: 'https://example.com/assets/bundle.js',
    resourceType: 'script',
    method: 'GET'
  });
  assert.strictEqual(c2.isApi, false);

  const c3 = ApiClassifier.classify({
    url: 'https://example.com/graphql',
    resourceType: 'other',
    method: 'POST'
  });
  assert.strictEqual(c3.isApi, true);

  // 2. Request Inventory Collection
  const inv = new RequestInventory('https://example.com');
  inv.addRequest({
    url: 'https://example.com/api/products',
    method: 'GET',
    status: 200,
    duration: 120,
    resourceType: 'fetch',
    size: 2048
  });
  inv.addRequest({
    url: 'https://example.com/api/products',
    method: 'GET',
    status: 200,
    duration: 110,
    resourceType: 'fetch',
    size: 2048
  });

  const summary = inv.getSummary();
  assert.strictEqual(summary.totalRequests, 2);
  assert.strictEqual(summary.apiRequestsCount, 2);

  // 3. Duplicate Detection
  const duplicates = WaterfallDetector.findDuplicates(inv.getAll());
  assert.strictEqual(duplicates.length, 1);
  assert.strictEqual(duplicates[0].count, 2);
  assert.strictEqual(duplicates[0].url, 'https://example.com/api/products');

  console.log('✓ API Classifier & Waterfall Detector tests passed.');
}

module.exports = testApiClassifier;
if (require.main === module) testApiClassifier();
