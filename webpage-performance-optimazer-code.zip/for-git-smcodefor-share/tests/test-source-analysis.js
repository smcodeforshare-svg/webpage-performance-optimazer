const assert = require('assert');
const path = require('path');
const fs = require('fs');
const ReactRules = require('../src/react-analysis/react-rules');
const PythonRules = require('../src/python-analysis/python-rules');
const CssRules = require('../src/css-analysis/css-rules');
const DependencyRules = require('../src/dependency-analysis/dependency-rules');
const ProjectScanner = require('../src/source-analysis/project-scanner');

function testSourceAnalysis() {
  console.log('Running test: Source Code Bottleneck Analysis...');

  const examplesDir = path.resolve(__dirname, '..', 'examples');

  // 1. React Rules Test
  const reactFile = path.join(examplesDir, 'sample-react-app', 'src', 'components', 'ProductList.jsx');
  const reactContent = fs.readFileSync(reactFile, 'utf8');
  const reactFindings = ReactRules.analyze(reactContent, 'src/components/ProductList.jsx', reactFile);

  assert.ok(reactFindings.length >= 3, `Expected at least 3 React findings, got ${reactFindings.length}`);
  
  const hasAbort = reactFindings.some(f => f.category === 'react-lifecycle' && f.title.includes('Request Cancellation'));
  assert.ok(hasAbort, 'Should detect missing AbortController in useEffect');

  const hasIndexKey = reactFindings.some(f => f.category === 'react-reconciliation');
  assert.ok(hasIndexKey, 'Should detect array index as React key');

  const hasMoment = reactFindings.some(f => f.title.includes('Moment.js'));
  assert.ok(hasMoment, 'Should detect heavy Moment.js import');

  // Verify line numbers are positive integers
  for (const f of reactFindings) {
    assert.ok(f.startLine > 0, 'startLine must be > 0');
    assert.ok(f.endLine >= f.startLine, 'endLine must be >= startLine');
    assert.ok(f.existingCode.length > 0, 'existingCode must not be empty');
    assert.ok(f.replacementCode.length > 0, 'replacementCode must not be empty');
  }

  // 2. Python Rules Test
  const pyFile = path.join(examplesDir, 'sample-python-api', 'app', 'api.py');
  const pyContent = fs.readFileSync(pyFile, 'utf8');
  const pyFindings = PythonRules.analyze(pyContent, 'app/api.py', pyFile);

  assert.ok(pyFindings.length >= 1, `Expected at least 1 Python finding, got ${pyFindings.length}`);
  const hasBlocking = pyFindings.some(f => f.category === 'python-async-blocking' || f.category === 'python-missing-timeout');
  assert.ok(hasBlocking, 'Should detect blocking or timeout issues in Python endpoint');

  // 3. CSS Rules Test
  const cssFile = path.join(examplesDir, 'sample-css-project', 'styles', 'animations.css');
  const cssContent = fs.readFileSync(cssFile, 'utf8');
  const cssFindings = CssRules.analyze(cssContent, 'styles/animations.css', cssFile);

  assert.ok(cssFindings.length >= 1, `Expected layout animation finding in CSS, got ${cssFindings.length}`);
  assert.strictEqual(cssFindings[0].category, 'css-paint-layout');

  // 4. Dependency Rules Test
  const pkgFile = path.join(examplesDir, 'sample-react-app', 'package.json');
  const pkgContent = fs.readFileSync(pkgFile, 'utf8');
  const depFindings = DependencyRules.analyzePackageJson(pkgContent, 'package.json', pkgFile);

  assert.ok(depFindings.length >= 2, `Expected at least 2 dependency findings (moment, lodash), got ${depFindings.length}`);

  // 5. Full ProjectScanner on sample-react-app
  const scanResult = ProjectScanner.scan(path.join(examplesDir, 'sample-react-app'));
  assert.ok(scanResult.totalFilesScanned >= 3, 'Should scan React files');
  assert.ok(scanResult.findings.length >= 4, 'Should detect combined findings');

  console.log('✓ Source Code Analysis tests passed.');
}

module.exports = testSourceAnalysis;
if (require.main === module) testSourceAnalysis();
